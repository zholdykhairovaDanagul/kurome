//
//  TableViewCell.swift
//  SimpleFirebaseApp
//
//  Created by Aidana Ketebay on 11.04.18.
//  Copyright © 2018 SDU. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    //@IBOutlet weak var PlayButton: UIButton!
    //func ff(){
      //  PlayButton.isHidden = false;
    //}
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
