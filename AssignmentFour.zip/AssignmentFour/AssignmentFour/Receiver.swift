//
//  Receiver.swift
//  AssignmentFour
//
//  Created by Dana  Zholdykhairova on 2/21/18.
//  Copyright © 2018 Dana  Zholdykhairova. All rights reserved.
//

import Foundation
protocol Receiver {
    func save(a website: sites)
    func saveFavour(a website: sites)
}
